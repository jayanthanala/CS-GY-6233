#include "types.h"
#include "user.h"

#define NUM_ITEMS 200

int
randomrange(int lo, int hi){
  if (hi < lo) {
    int tmp = lo;
    lo = hi;
    hi = tmp;
  }
  int range = hi - lo + 1;
  return random() % (range) + lo;
}

// 2^20 - 4894887 (random_at_range(1x) -> rand)

int
main(int argc, char *argv[])
{
  printf(1, "--- random test ---\n");
  int i;
  printf(1, ">> random nos b/w 0 and 2147483647:\n");
  for (i = 0; i < NUM_ITEMS; i++) {
    printf(1, "%d ", random());
  }
  printf(1, "\n");
  printf(1, ">> random nos b/w 0 and 10:\n");
  for (i = 0; i < NUM_ITEMS; i++) {
    int d = randomrange(0, 10);
    printf(1, "%d ", d);
  }
  printf(1, "\n");
  printf(1, ">> random nos b/w 1 and 1050:\n");
  for (i = 0; i < NUM_ITEMS; i++) {
    int d = randomrange(1, 1050);
    printf(1, "%d ", d);
  }
  printf(1, "\n");
  printf(1, ">> random nos b/w -99 and 10:\n");
  for (i = 0; i < NUM_ITEMS; i++) {
    int d = randomrange(-99, 100);
    printf(1, "%d ", d);
  }
  printf(1, "\n");
  printf(1, ">> random nos b/w 1 and 1:\n");
  for (i = 0; i < NUM_ITEMS; i++) {   //just a test case for 1
    int d = randomrange(1, 1);
    printf(1, "%d ", d);
  }
  printf(1, "\n");
  exit();
}
