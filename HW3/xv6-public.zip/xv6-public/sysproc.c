#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_random(void)
{
  return random();
}

// int 
// sys_schtype(void){
//   int flag, ret_flag;
//   if(argint(0,&flag)<0){
//     return -1;
//   }
//    if (flag == 0 || flag == 1) {
//     ret_flag = schtype(flag);
//     return ret_flag;
//   }
//   else {
//     flag = 0;
//     ret_flag = schtype(0);
//     return ret_flag;
//   }
//   return -1;
// }

int
sys_nicepr(void)
{
  int pid, pr;
  if(argint(0, &pid) < 0)
    return -1;
  if(argint(1, &pr) < 0)
    return -1;
  // if (pr > 20) // prevent prior val > 20
  //   pr = 20;
  // else if (pr < 0 ) // prevent prior val < 0
  //   pr = 0; 
  // else
  //   pr = pr;
  return nicepr(pid, pr);
}

int sys_nice(void) {
  // The priority for a process ranges from -19 to 20 with -19 being the highest priority and 20 the lowest
  // int n;
  // if (argint(0, &n) < 0)
  //   return -1;
  
  // if (n < 0) { 
  //   return -1;
  // }
  // else if (n > 20) {
  //   proc->priority = 20;
  //   proc->tickets = 4;  
  // }
  // else {
  //   proc->priority = n;
  //   if(n==0){
  //     proc->tickets = 160;
  //   }
  //   else{
  //     proc->tickets = 160 - (4*n);
  //   }
  // }
  // return proc->priority;

  int inc;
  argint(0, &inc);
  if (inc > 20 || proc->priority + inc > 20) // prevent prior val > 20
    proc->priority = 20;
  else if (inc < -20 || proc->priority + inc < 0) // prevent prior val < 0
    proc->priority = 0; 
  else
    proc->priority += inc;
  return (int) proc->priority;
}


int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
