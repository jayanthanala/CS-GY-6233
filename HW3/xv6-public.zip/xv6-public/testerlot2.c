#include "types.h"
#include "stat.h"
#include "user.h"

int is_prime(long prime_no){
    long i, num = prime_no, temp = 0; 
    for (i = 2; i <= num / 2; i++){
        if (num % i == 0){
            temp++;
            break;
        }
    } 
    if (temp == 0 && num != 1){
        printf(1, "%d is a Prime number!\n", num);
    }else{
        printf(1, "%d is not a Prime number!\n", num);
    }
    return 0;
}

int main(void) {
    if(fork() != 0){
        if(fork() != 0){
            wait();   
        }else{
            printf(1, "Highest priortiy set for Child 2: %d\n", nice(-5));
            is_prime(179424673);
            printf(1, "Child 2 exit!\n");
        }
        wait();
    }else{
        printf(1, "Lowest priortiy set for Child 1: %d\n", nice(50));
        is_prime(179424673);
        printf(1, "Child 1 exit!\n");
    }
    exit();
}