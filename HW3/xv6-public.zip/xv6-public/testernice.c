#include "types.h"
#include "user.h"

//clamping is also done as mentioned in the hw3 document
// Jayanth Anala - ja4874

int main(int argc, char *argv[]){
  printf(1, "--- nice sys call tester ---\n");

  int nprior, oprior = nice(0); // get current priortiy val ( increase by 0)
  if (oprior < 10) {
    nprior = nice(5); // increase by 5
    if (nprior == oprior + 5) {
      printf(1, "Process: %d, nice(5) call success, old_priority: %d, new priority value: %d\n", getpid(),oprior,nprior);
    } else {
      printf(1, "nice(5) failed. old_priority: %d, new_priority: %d\n", oprior, nprior);
    }
  } else {
    nprior = nice(-5); // red by 5
    if (nprior == oprior - 5){
      printf(1, "Process: %d, nice(-5) call success,old_priority: %d, new priority value: %d\n", getpid(),oprior,nprior);
    } else {
      printf(1, "nice(-5) failed. old_priority: %d, new_priority: %d\n", oprior, nprior);
    }
  }

  oprior = nice(0);
  nprior = nice(100); // inc by > 20
  if (nprior == 20) {
    printf(1, "Process: %d, successfully called nice(100), old_prior: %d, new_priority value: %d\n", getpid(), oprior, nprior);
  } else {
    printf(1, "nice(100) failed\n");
  }

  oprior = nice(0);
  nprior = nice(-100); // inc by < 20
  if (nprior == 0) {
    printf(1, "Process: %d, successfully called nice(-100), old_priority: %d, new_priority value: %d\n", getpid(), oprior, nprior);
  } else {
    printf(1, "nice(-100) failed\n");
  }

  printf(1, "Process: %d, old_priority: %d, new_priority value: %d\n", getpid(), nprior, nicepr(getpid(),15));

  exit();
}
