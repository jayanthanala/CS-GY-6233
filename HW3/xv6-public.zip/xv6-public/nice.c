#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int priority, pid;
  if(argc < 3){
    printf(1,"syntax: nice <pid> <priority>\n");
    exit();
  }
  pid = atoi(argv[1]);
  priority = atoi(argv[2]);
  if (priority < 0 || priority > 20){
    printf(1,"wrong priority values given use (0-20)!\n");
    exit();
  }
  nicepr(pid, priority);
  exit();
}