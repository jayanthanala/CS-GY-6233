#include "types.h"
#include "stat.h"
#include "user.h"

int 
main (void)
{
    if(fork() != 0){
        if(fork() != 0){
            if(fork() != 0){
                wait(); 
            }else {
                printf(1, "START: Child 3 created, priority - [%d]\n", nice(-10));
                volatile unsigned long long i;
                for (i = 0; i < 1000000000ULL; ++i);
                printf(1, "STOP:child 3 exit!\n");
            }
           wait();  
        }else {
            printf(1, "START: Child 2 created, priority - [%d]\n", nice(-5));
            volatile unsigned long long i;
            for (i = 0; i < 1000000000ULL; ++i);
            printf(1, "STOP:chidl 2 exit!\n");
            }
        // wait();  
        wait();   
    }
    else {
        printf(1, "START: Child 1 created, priority - [%d]\n", nice(100));
        volatile unsigned long long i;
        for (i = 0; i < 1000000000ULL; ++i);
        printf(1, "STOP:child 1 exit!\n");
    }
    exit();
}

