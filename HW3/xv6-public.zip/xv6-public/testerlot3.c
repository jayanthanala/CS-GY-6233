// Test case fro dynamically updating the priority of the child.
// Jayanth Anala - ja4874

#include "types.h"
#include "stat.h"
#include "user.h"



int main(void) {
    if(fork() != 0){
        if(fork() != 0){
         wait();   
        }
        else {
            printf(1, "Child 2 created with highest priority [%d]\n", nice(-5));
            int num=0,i;
            for (i = 0; i < 150; i++){
                num = num + i*0.2;
                printf(1, "child 2 >result: %d\n", num);
                if(i==50){
                    printf(1, "child 2 priority now changed to lowest: [%d]\n", nice(100));
                }
            }
            printf(1, "--Child 2 exit--\n");
        }
        wait();   
    }else {
        printf(1, "Child 1 created with lowest priority [%d]\n", nice(100));
        int num=0,j;
        for (j = 0; j < 150; j++){
            num = num + j*0.2;
            printf(1, "child 1 >result: %d\n", num);
            if(j==15){
                    printf(1, "child 1 priority now changed to highest: [%d]\n", nice(-5));
                }
        }
        printf(1, "--Child 1 exit--\n");
    }
    exit();
}